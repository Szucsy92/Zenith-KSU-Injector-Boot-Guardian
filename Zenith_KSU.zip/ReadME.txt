+-----------------------------------------------------------------------------+
|                     ZENITH-KSU PROJECT DOCUMENTATION v1.0                   |
|          The Highest Point of Android Stability & Module Management         |
+-----------------------------------------------------------------------------+

[1] PROJECT OVERVIEW
-------------------------------------------------------------------------------
Zenith-KSU is an integrated system-level solution designed for OneUI-based ROMs.
It provides a two-layered defense and automation system:
1. Bootloop Guardian: Prevents permanent bootloops by monitoring boot success.
2. KSU Injector: Automatically restores customized KernelSU modules from system to data.
-------------------------------------------------------------------------------

+-----------------------------------------------------------------------------+
| [2] BUILD-TIME CONFIGURATION (CRB / UKA)                                    |
+-----------------------------------------------------------------------------+

SELinux Security Labels (system_filesystem_config.txt)
--------------------------------------------------
Add these lines to ensure the binary scripts have the correct execution bits.
The su_exec label is mandatory for the injection script to operate with root privileges.

/system/system/bin/apex_check\.sh u:object_r:system_file:s0
/system/system/bin/apex_reset\.sh u:object_r:system_file:s0
/system/system/bin/ksu_init\.sh u:object_r:su_exec:s0
/system/system/bin/boot_guardian\.sh u:object_r:system_file:s0
/system/system/bin/zenith u:object_r:system_file:s0
/system/system/etc/init/apex_fix\.rc u:object_r:system_file:s0
/system/system/etc/init/init\.ksu_prep\.rc u:object_r:system_file:s0

(this files flags is for the UKA exactly. but usable for the CRB also)

Filesystem Permissions
--------------------------------------------------------

system/bin/ksu_init.sh 0 2000 0755
system/bin/apex_check.sh 0 2000 0755
system/bin/apex_reset.sh 0 2000 0755
system/bin/boot_guardian.sh 0 2000 0755
system/bin/zenith 0 2000 0755
system/etc/init/init.ksu_prep.rc 0 0 0644
system/etc/init/apex_fix.rc 0 0 0644

+-----------------------------------------------------------------------------+
| [3] MAINTENANCE COMMANDS (TERMUX / ADB SHELL)                               |
+-----------------------------------------------------------------------------+

Update Integrated Modules:
--------------------------
Use this command to sync your current module setup into the ROM's system:

su -c "mount -o remount,rw / && \
rm -rf /system/usr/share/ksu_modules/adb && \
mkdir -p /system/usr/share/ksu_modules && \
cp -a /data/adb /system/usr/share/ksu_modules/ && \
rm -rf /system/usr/share/ksu_modules/adb/ksu && \
restorecon -Rv /system/usr/share/ksu_modules/adb && \
mount -o remount,ro / && \
echo '--- Done! /system/usr/share/ksu_modules/adb has been refreshed! ---'"

Full System/Data Clean (modules)
-----------------------
Use this command to wipe all modules for a fresh start:

su -c "mount -o remount,rw / && \
rm -rf /data/adb && \
rm -rf /system/usr/share/ksu_modules/adb && \
mkdir -p /system/usr/share/ksu_modules && \
mount -o remount,ro / && \
echo '--- Done! All clear. ---'"




OR!!!!!!

use the termux grant root permission
type zenith


That's all :)

+-----------------------------------------------------------------------------+
| [4] IMPORTANT TECHNICAL NOTES                                               |
+-----------------------------------------------------------------------------+
- LINE ENDINGS: All .sh and .rc files must use UNIX (LF) format.
- SYSTEM-AS-ROOT: All manual mount commands target /system/system.
- BOOT LIMIT: Guardian triggers Recovery reboot after 5 failed attempts.
- APEX WIPE: Triggered automatically on the 2nd failed attempt.

-Use the files free in your rom ports.
-------------------------------------------------------------------------------
Created by: @szucsy92 & @A1X31
+-----------------------------------------------------------------------------+
